//const { json } = require('stream/consumers');
const writeBuffer = require('fs')
const resultBuffer = require('fs').readFileSync('openStreetMapData.txt');
const resultData = JSON.parse(resultBuffer.toString().trim());

// console.log(resultData['elements'])
var coordinates = resultData["elements"].filter(i=>i.type ===
    'node')

//y is the latitude so first find the lowest y 

console.log('start');
//find the lowest latitude (y axis)
let LowestPoint = coordinates[0];
var lowestIndex = 0;
coordinates.forEach((element,index) => {
    if(LowestPoint.lon >= element.lon){
        LowestPoint = element;
        lowestIndex = index;
    }
});


//orientation function

function orientation(point1, point2, point3){
    let val = (point2.lat - point1.lat) *(point3.lon-point2.lon) -
            (point2.lon-point1.lon) *(point3.lat - point2.lat)

            
            if(val===0) return 0;
            
            return (val > 0)? 1:2;
}

var OuterHexagon = []
let p = lowestIndex, q;
//72
// console.log(p);
do{
   OuterHexagon.push(coordinates[p]);
   
    q = (p + 1)%coordinates.length;
    for(let i = 0;i<coordinates.length;i++){
        if(orientation(coordinates[p],coordinates[i],coordinates[q])===2){
            q=i;

            // console.log(q);
        }
        
    }
    p=q;
    

}while(p!==lowestIndex);


console.log(OuterHexagon)
console.log('done');
writeBuffer.writeFileSync("convexHull.txt",JSON.stringify(OuterHexagon) )
writeBuffer.writeFileSync("coordinates.txt",JSON.stringify(coordinates) )

//const writeBuffer = require('fs').writeFileSync("convexHull.txt",JSON.stringify(OuterHexagon));

/*
jarvis(S)
   // S is the set of points
   pointOnHull = leftmost point in S //which is guaranteed to be part of the Hull(S)
   i = 0
   repeat
      P[i] = pointOnHull
      endpoint = S[0]      // initial endpoint for a candidate edge on the hull
      for j from 1 to |S|
         if (endpoint == pointOnHull) or (S[j] is on left of line from P[i] to endpoint)
            endpoint = S[j]   // found greater left turn, update endpoint
      i = i+1
      pointOnHull = endpoint
   until endpoint == P[0]      // wrapped around to first hull point
*/


