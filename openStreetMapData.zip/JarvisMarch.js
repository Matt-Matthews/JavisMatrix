const resultBuffer = fs.readFileSync('result.txt');
const resultData = JSON.parse(resultBuffer.toString().trim());

var coordinates = resultData["elements"]
//y is the latitude so first find the lowest y 


//fiind the lowest latitude (y axis)
LowestLat = coordinates[0].lat;
coordinates.array.forEach(element => {
    if(LowestLat >= element.lat){
        LowestLat == element.lat
    }
});




